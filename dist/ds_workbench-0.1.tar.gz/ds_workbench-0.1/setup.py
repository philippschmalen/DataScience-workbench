from setuptools import setup

setup(name='ds_workbench',
      version='0.1',
      description='Utilities for data science projects',
      packages=['workbench'],
      author = 'Philipp Schmalen',
      author_email = 'philippschmalen@gmail.com',
      zip_safe=False)
